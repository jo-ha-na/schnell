package com.example.powpow;
public class Events {

    String idEvent, designation, lieu, date;

    public Events() {



    }
    public Events(String idEvent, String designation, String lieu, String date) {

        this.idEvent = idEvent;
        this.designation = designation;
        this.lieu = lieu;
        this.date = date;

    }

    public String getIdEvent() {
        return idEvent;
    }

    public void setFirstName(String idEvent) {
        this.idEvent = idEvent;
    }

    public String getDesignation() {
        return designation;
    }

    public void setLastName(String designation) {
        this.designation = designation;
    }

    public String getLieu() {
        return lieu;
    }

    public void setLieu(String lieu) {
        this.lieu = lieu;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
