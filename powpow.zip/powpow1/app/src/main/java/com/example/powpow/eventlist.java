package com.example.powpow;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.sql.Array;
import java.util.ArrayList;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class eventlist extends AppCompatActivity {


    RecyclerView recyclerView;
    DatabaseReference database;
    MyEventAdapter myEventAdapter;

    ArrayList<Events> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventlist);

        recyclerView = findViewById(R.id.eventList);
        database = FirebaseDatabase.getInstance().getReference("Events");
        recyclerView.setHasFixedSize(true);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        list = new ArrayList<>();
        myEventAdapter = new MyEventAdapter(this, list);
        recyclerView.setAdapter(myEventAdapter);

        final String idEventToRetrieve = getIntent().getStringExtra("idEvent");

        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Events events = dataSnapshot.getValue(Events.class);


                    if (events != null && events.getIdEvent().equals(idEventToRetrieve)) {
                        list.add(events);
                    }

                }

                myEventAdapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
}