package com.example.powpow;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.media.metrics.Event;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class MyEventAdapter extends RecyclerView.Adapter<MyEventAdapter.MyViewHolder> {

    Context context;
    ArrayList<Events> list;

    public MyEventAdapter(Context context, ArrayList<Events> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        Events events = list.get(position);
        holder.idEvent.setText(events.getIdEvent());
        holder.designation.setText(events.getDesignation());
        holder.lieu.setText(events.getLieu());
        holder.date.setText(events.getDate());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView idEvent, designation, lieu, date;
        public MyViewHolder(@NonNull View itemView) {

            super(itemView);

            idEvent = itemView.findViewById(R.id.tvidEvent);
            designation = itemView.findViewById(R.id.tvdesignation);
            lieu = itemView.findViewById(R.id.tvlieu);
            date = itemView.findViewById(R.id.tvdate);


        }

    }


}