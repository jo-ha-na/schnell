package com.example.letsgo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Fonctions {

    public static String url = "jdbc:mysql://db4free.net:3306/bddsql4project";

    public static String db_user = "rooting4me";

    public static String db_password = "rooting4me";

    public static Statement connexionSQLBDD (){

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url,db_user,db_password);
            Statement st = conn.createStatement();
            return st;


        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        } catch (SQLException e) {

            e.printStackTrace();
            return null;
        }



    };

}
